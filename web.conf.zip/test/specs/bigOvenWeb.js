// const { expect, driver } = require("@wdio/globals");
// const allureReporter = require("@wdio/allure-reporter").default;
// const LoginPage = require("../pageobjects/login.page");
// const page = require("../pageobjects/page");
// const dashboardPage = require("../pageobjects/login.page");
// const bigOvenWebPage = require("../pageobjects/bigOvenWeb.page");
// const testData = require("../../data/bigOvenTestData.json");
// const utilTools = require("../utils/tools");
// require("dotenv").config();

// describe("Verify bigOven application", () => {
//   it("user should login with valid credentials", async () => {
//     await bigOvenWebPage.enterIntoWebApplication(process.env.url);
   
//   });

// });